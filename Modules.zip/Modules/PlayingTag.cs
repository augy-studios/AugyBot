﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules
{
    public class PlayingTag : ModuleBase<SocketCommandContext>
    {
        [Command("SetGame")]
        [Alias("setgame", "game")]
        [Summary("Sets a 'Game' for the bot")]
        public async Task SetGame([Remainder] string game)
        {
            await (Context.Client as DiscordSocketClient).SetGameAsync(game);
            await Context.Channel.SendMessageAsync($"Successfully set the game to *{game}*");
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} changed the game to {game}");
        }
    }
}
