﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules
{
    public class Welcome : ModuleBase<SocketCommandContext>
    {
        [Command("welcome")]
        public async Task PingUser(SocketGuildUser user)
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!welcome {user}");

            await ReplyAsync($"{user.Mention}, Welcome to the server!");
        }
    }
}
