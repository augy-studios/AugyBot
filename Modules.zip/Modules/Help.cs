﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules
{
    [Group("help")]
    [Alias("info")]
    public class Help : ModuleBase<SocketCommandContext>
    {
        [Command]
        public async Task HelpCommand()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help");

            await Context.Client.SetGameAsync("a!help | " + (Context.Client as DiscordSocketClient).Guilds.Count.ToString() + " servers" + " | " + (Context.Client as DiscordSocketClient).Guilds.Sum(g => g.Users.Count).ToString() + " users");

            EmbedBuilder embedBuilder;
            embedBuilder = new EmbedBuilder();
            embedBuilder.WithColor(new Color(0, 255, 0));

            embedBuilder.Title = $"Here are the available commands!";
            //embedBuilder.Footer.Text = $"a!help [command] for more info on a specific command.";
            embedBuilder.Description =
                $":information_source: **Shows this message**\n" +
                $"help\n" +
                $":tools: **Information**\n" +
                $"ping, invite, server, credits, userinfo, serverinfo, botinfo, changelog\n" +
                /*$":couple: **All About User**\n" +
                $"userinfo, useravatar, usercreatedate, userid, userstatus, userplaying, userdiscrim, userjoindate\n" +
                $":globe_with_meridians: **All About Server**\n" +
                $"serverinfo, screatedate, sconnection, serverid, smembercount, snotifications, sregion, srolecount, servervl\n" +
                $":robot: **All About Bot**\n" +
                $"botinfo, servers, uptime, users, channels\n" +*/
                $":stuck_out_tongue_winking_eye: **Fun Commands**\n" +
                $"txtface, 8ball, randquote, repeat, choose, ratewaifu\n" +
                $":writing_hand: **Miscellaneous**\n" +
                $"feedback, suggest, report\n\n" +
                $"a!help [command] for more info on a specific command.";

            /*EmbedBuilder embedBuilder1;
            embedBuilder1 = new EmbedBuilder();
            embedBuilder1.WithColor(new Color(0, 255, 0));

            embedBuilder1.Title = $"Here are the commands that are currently in development.";
            embedBuilder1.Description = $"kick\n" +
                $"ban\n" +                                
                $"clear\n" +
                $"fight\n" +
                $"giveup\n" +
                $"cat\n" +
                $"setgame\n";*/

            await ReplyAsync("", false, embedBuilder);
            //await ReplyAsync("", false, embedBuilder1);
        }

        [Command("ping")]
        public async Task CmdHelp1()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help ping");
            await ReplyAsync($"``ping`` command returns ping to user\n Uses: ``a!ping`` ``A!ping user @mention``");
        }

        [Command("invite")]
        public async Task CmdHelp2()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help invite");
            await ReplyAsync($"``invite`` command provides OAuth invite link for the bot\n Uses: ``a!invite``");
        }

        [Command("userinfo")]
        public async Task CmdHelp3()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help userinfo");
            await ReplyAsync($"``userinfo`` command returns mentioned user's information\n Uses: ``a!userinfo @mention`` ``a!uinfo @mention``");
        }

        [Command("serverinfo")]
        public async Task CmdHelp4()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help serverinfo");
            await ReplyAsync($"``serverinfo`` command returns info of the current server the bot is in\n Uses: ``a!serverinfo`` ``a!sinfo`` ``a!servinfo``");
        }

        [Command("botinfo")]
        public async Task CmdHelp5()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help botinfo");
            await ReplyAsync($"``botinfo`` command returns info of the bot\n Uses: ``a!botinfo`` ``a!binfo``");
        }

        [Command("fight")]
        public async Task CmdHelp6()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help fight");
            await ReplyAsync($"``fight`` command starts a fight with the user you mentioned\n Uses: ``a!fight @mention``");
        }

        [Command("giveup")]
        public async Task CmdHelp7()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help giveup");
            await ReplyAsync($"``giveup`` command stops the current fight\n Uses: ``a!giveup``");
        }

        [Command("txtface")]
        public async Task CmdHelp8()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help txtface");
            await ReplyAsync($"``txtface`` command returns text faces\n Uses: ``a!txtface`` ``a!txtface list``\n ©FT18");
        }

        [Command("useravatar")]
        public async Task CmdHelp9()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help useravatar");
            await ReplyAsync($"``useravatar`` command returns mentioned user's avatar\n Uses: ``a!useravatar @mention`` ``a!uavatar @mention`` ``a!upicture @mention`` ``a!uimage @mention``");
        }

        [Command("server")]
        public async Task CmdHelp10()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help server");
            await ReplyAsync($"``server`` command provides invite link to support server\n Uses: ``a!server`` ``a!botserver`` ``a!support`` ``a!sinvite``");
        }

        [Command("repeat")]
        public async Task CmdHelp11()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help repeat");
            await ReplyAsync($"``repeat`` command repeats the user's text\n Uses: ``a!rpt`` ``a!say``");
        }

        [Command("8ball")]
        public async Task CmdHelp12()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help 8ball");
            await ReplyAsync($"``8ball`` command returns a decision\n Uses: ``a!8ball [Question]`` ``a!eightball [Question]``\n ©FT18");
        }

        [Command("randquote")]
        public async Task CmdHelp13()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help randquote");
            await ReplyAsync($"``randquote`` command returns a random quote\n Uses: ``a!quote`` ``a!randquote`` ``a!randomquote`` ``a!rquote``");
        }

        [Command("cat")]
        public async Task CmdHelp14()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help cat");
            await ReplyAsync($"``cat`` command returns a random image of a cat\n Uses: ``a!cat``");
        }

        [Command("usercreatedate")]
        public async Task CmdHelp15()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help usercreatedate");
            await ReplyAsync($"``usercreatedate`` command returns mentioned user's account creation date\n Uses: ``a!usercreatedate @mention`` ``a!ucreatedate @mention`` ``a!ucreated @mention`` ``a!ucdate @mention``");
        }

        [Command("userid")]
        public async Task CmdHelp16()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help userid");
            await ReplyAsync($"``userid`` command returns mentioned user's ID\n Uses: ``a!userid @mention`` ``a!uid @mention``");
        }

        [Command("userstatus")]
        public async Task CmdHelp17()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help userstatus");
            await ReplyAsync($"``userstatus`` command returns mentioned user's current status\n Uses: ``a!userstatus @mention`` ``a!ustatus @mention`` ``a!status @mention``");
        }

        [Command("userplaying")]
        public async Task CmdHelp18()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help userplaying");
            await ReplyAsync($"``userplaying`` command returns mentioned user's playing game\n Uses: ``a!userplaying @mention`` ``a!uplaying @mention``");
        }
        
        [Command("userdiscrim")]
        public async Task CmdHelp19()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help userdiscrim");
            await ReplyAsync($"``userdiscrim`` command returns mentioned user's discriminator\n Uses: ``a!userdiscrim @mention`` ``a!udiscrim @mention``");
        }

        [Command("userjoindate")]
        public async Task CmdHelp20()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help userjoindate");
            await ReplyAsync($"``userjoindate`` command returns mentioned user's join date in the server\n Uses: ``a!userjoindate @mention`` ``a!ujoindate @mention`` ``a!ujoined @mention`` ``a!ujdate @mention``");
        }

        [Command("feedback")]
        public async Task CmdHelp21()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help feedback");
            await ReplyAsync($"``feedback`` command sends a feedback to the #feedback channel in the AugyBot Support server\n Uses: ``a!feedback [feedback]``");
        }

        [Command("suggest")]
        public async Task CmdHelp22()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help suggest");
            await ReplyAsync($"``suggest`` command sends a suggestion to the #suggestions channel in the AugyBot Support server\n Uses: ``a!suggest [suggestion]``");
        }

        [Command("report")]
        public async Task CmdHelp23()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help report");
            await ReplyAsync($"``report`` command sends a report to the #reports channel in the AugyBot Support server\n Uses: ``a!report [report]``");
        }

        [Command("choose")]
        public async Task CmdHelp24()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help choose");
            await ReplyAsync($"``choose`` command returns an answer from a set of choices/options provided by the user (maximum 5 options)\n Uses: ``a!choose [options separated with space]``");
        }

        [Command("screatedate")]
        public async Task CmdHelp25()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help screatedate");
            await ReplyAsync($"``screatedate`` command returns the server's created date\n Uses: ``a!screatedate`` ``a!screated`` ``a!scdate``");
        }

        [Command("sconnection")]
        public async Task CmdHelp26()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help sconnection");
            await ReplyAsync($"``sconnection`` command returns the server's connection state\n Uses: ``a!sconnection`` ``a!sconnect`` ``a!sstate``");
        }

        [Command("serverid")]
        public async Task CmdHelp27()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help serverid");
            await ReplyAsync($"``serverid`` command returns the server's ID\n Uses: ``a!serverid`` ``a!sid``");
        }

        [Command("smembercount")]
        public async Task CmdHelp28()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help smembercount");
            await ReplyAsync($"``smembercount`` command returns the server's member count\n Uses: ``a!smembercount`` ``a!smembers``");
        }

        [Command("snotifications")]
        public async Task CmdHelp29()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help snotifications");
            await ReplyAsync($"``snotifications`` command returns the server's default message notifications settings\n Uses: ``a!snotifications`` ``a!servernotif`` ``a!smsgntfc`` ``a!snotif``");
        }

        [Command("sregion")]
        public async Task CmdHelp30()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help sregion");
            await ReplyAsync($"``sregion`` command returns the server's region\n Uses: ``a!sregion`` ``a!scountry`` ``a!scty``");
        }

        [Command("srolecount")]
        public async Task CmdHelp31()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help srolecount");
            await ReplyAsync($"``srolecount`` command returns the server's role count\n Uses: ``a!srolecount`` ``a!sroles``");
        }

        [Command("servervl")]
        public async Task CmdHelp32()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help servervl");
            await ReplyAsync($"``servervl`` command returns a random quote\n Uses: ``a!servervl`` ``a!svl``");
        }

        [Command("ratewaifu")]
        public async Task CmdHelp33()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help ratewaifu");
            await ReplyAsync($"``ratewaifu`` command returns a rating\n Uses: ``a!ratewaifu`` ``a!rate``\n");
        }

        [Command("servers")]
        public async Task CmdHelp34()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help servers");
            await ReplyAsync($"``servers`` command returns the number of servers the bot's serving\n Uses: ``a!servers`` ``a!servercount`` ``a!scount``");
        }

        [Command("uptime")]
        public async Task CmdHelp35()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help uptime");
            await ReplyAsync($"``uptime`` command returns the bot's uptime\n Uses: ``a!uptime``");
        }

        [Command("users")]
        public async Task CmdHelp36()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help users");
            await ReplyAsync($"``users`` command returns the number of users the bot's serving\n Uses: ``a!users`` ``a!usercount`` ``a!ucount``");
        }

        [Command("channels")]
        public async Task CmdHelp37()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help channels");
            await ReplyAsync($"``channels`` command returns the number of channels the bot's serving\n Uses: ``a!channels`` ``a!channelcount`` ``a!ccount``");
        }

        [Command("credits")]
        public async Task CmdHelp38()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help credits");
            await ReplyAsync($"``credits`` command returns the credits\n Uses: ``a!credits``");
        }

        [Command("changelog")]
        public async Task CmdHelp39()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!help changelog");
            await ReplyAsync($"``changelog`` command returns the change log\n Uses: ``a!changelog`` ``a!changes``");
        }
    }
}
