﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules.Fun
{
    public class RateWaifu : ModuleBase<SocketCommandContext>
    {
        string[] rating = new string[]
        {
            "0/10",
            "1/10",
            "2/10",
            "3/10",
            "4/10",
            "5/10",
            "6/10",
            "7/10",
            "8/10",
            "9/10",
            "10/10",
        };

        Random rand = new Random();

        [Command("ratewaifu")]
        [Alias("rate")]
        [Summary("Gives a rating")]
        public async Task GiveRating([Remainder] string input)
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!ratewaifu {input}");

            if (string.IsNullOrWhiteSpace(input))
            {
                int randomIndex = rand.Next(rating.Length);
                string text = rating[randomIndex];
                await ReplyAsync(Context.User.Mention + ", you are rated " + text + "!");
            }
            if (input == "John Cena")
            {
                await ReplyAsync(Context.User.Mention + ", **John Cena** is rated 11/10!");
            }
            else
            {
                int randomIndex = rand.Next(rating.Length);
                string text = rating[randomIndex];
                await ReplyAsync(Context.User.Mention + ", **" + input + "** is rated " + text + "!");
            }
        }
    }
}
