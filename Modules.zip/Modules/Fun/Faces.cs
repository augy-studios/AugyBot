﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules
{
    [Group("txtface")]
    [Alias("txtfc", "txtfcs")]
    public class Faces : ModuleBase<SocketCommandContext>
    {
        [Command]
        public async Task DefaultPing()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface");

            await ReplyAsync($"**txtface** command syntax is ``A!txtface [facename]`` Check list with ``A!txtface list``");
        }

        [Command("list")]
        public async Task DefaultPing1()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface list");

            EmbedBuilder embedBuilder;
            embedBuilder = new EmbedBuilder();
            embedBuilder.WithColor(new Color(0, 0, 255));

            embedBuilder.Title = $"Here's the list of text faces!";
            embedBuilder.Description = $"lenny\n" +
                $"disapproval\n" +
                $"shock\n" +
                $"gungsterlenny\n" +
                $"gun\n" +
                $"ec-wizard\n" +
                $"many lenny\n" +
                $"5dollars\n" +
                $"lenny fight\n" +
                $"fight\n" +
                $"lenny dollar\n" +
                $"orly\n" +
                $"bear\n" +
                $"sparkly\n" +
                $"flipFB\n" +
                $"bear blush\n" +
                $"kiss\n" +
                $"heart eyes\n" +
                $"strong\n" +
                $"joyful\n" +
                $"kick\n" +
                $"dancing\n" +
                $"cat\n" +
                $"facepalm\n" +
                $"amazed\n" +
                $"happy\n" +
                $"tableflip\n" +
                $"kowtow\n" +
                $"cry\n" +
                $"wizard\n" +               
                $"dance\n" +
                $"sunglass lenny\n";

            await ReplyAsync("", false, embedBuilder);
        }

        [Command("lenny")]
        public async Task DefaultPing2()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface lenny");
            await ReplyAsync(Context.User.Mention + " | " + $"( ͡° ͜ʖ ͡°)");
        }

        [Command("disapproval")]
        public async Task DefaultPing3()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface disapproval");
            await ReplyAsync(Context.User.Mention + " | " + $"ಠ_ಠ");
        }

        [Command("shock")]
        public async Task DefaultPing4()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface shock");
            await ReplyAsync(Context.User.Mention + " | " + $"ʘ_ʘ");
        }

        [Command("gungsterlenny")]
        public async Task DefaultPing5()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface gungsterlenny");
            await ReplyAsync(Context.User.Mention + " | " + $"̿ ̿ ̿ ̿'̿'̵͇̿з=( ͠° ͟ʖ ͡°)=ε/̵͇̿/'̿̿ ̿ ̿ ̿ ̿ ̿");
        }

        [Command("gun")]
        public async Task DefaultPing6()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface gun");
            await ReplyAsync(Context.User.Mention + " | " + $"▄︻̷̿┻̿═━一");
        }

        [Command("ec-wizard")]
        public async Task DefaultPing7()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface ec-wizard");
            await ReplyAsync(Context.User.Mention + " | " + $"(∩•ω•)⊃━☆ﾟ.*");
        }

        [Command("many lenny")]
        public async Task DefaultPing8()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface many lenny");
            await ReplyAsync(Context.User.Mention + " | " + $"( ͡°( ͡° ͜ʖ( ͡° ͜ʖ ͡°)ʖ ͡°) ͡°)");
        }

        [Command("sunglass lenny")]
        public async Task DefaultPing9()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface sunglass lenny");
            await ReplyAsync(Context.User.Mention + " | " + $"(▀̿Ĺ̯▀̿ ̿)");
        }

        [Command("5dollars")]
        public async Task DefaultPing10()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface 5dollars");
            await ReplyAsync(Context.User.Mention + " | " + $"[̲̅$̲̅(̲̅5̲̅)̲̅$̲̅]");
        }

        [Command("lenny fight")]
        public async Task DefaultPing11()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface lenny fight");
            await ReplyAsync(Context.User.Mention + " | " + $"(ง ͠° ͟ل͜ ͡°)ง");
        }

        [Command("fight")]
        public async Task DefaultPing12()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface fight");
            await ReplyAsync(Context.User.Mention + " | " + $"(ง'̀-'́)ง");
        }

        [Command("lenny dollar")]
        public async Task DefaultPing13()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface lenny dollar");
            await ReplyAsync(Context.User.Mention + " | " + $"[̲̅$̲̅(̲̅ ͡° ͜ʖ ͡°̲̅)̲̅$̲̅]");
        }

        [Command("orly")]
        public async Task DefaultPing14()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface orly");
            await ReplyAsync(Context.User.Mention + " | " + $"﴾͡๏̯͡๏﴿ O'RLY?");
        }

        [Command("bear")]
        public async Task DefaultPing15()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface bear");
            await ReplyAsync(Context.User.Mention + " | " + $"ʕ•ᴥ•ʔ");
        }

        [Command("sparkly")]
        public async Task DefaultPing16()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface sparkly");
            await ReplyAsync(Context.User.Mention + " | " + $"(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧");
        }

        [Command("flipFB")]
        public async Task DefaultPing17()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface flipFB");
            await ReplyAsync(Context.User.Mention + " | " + $"(╯°□°)╯︵ ʞooqǝɔɐɟ");
        }

        [Command("bear blush")]
        public async Task DefaultPing18()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface bear blush");
            await ReplyAsync(Context.User.Mention + " | " + $"(ᵔᴥᵔ)");
        }

        [Command("kiss")]
        public async Task DefaultPing19()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface kiss");
            await ReplyAsync(Context.User.Mention + " | " + $"(づ￣ ³￣)づ");
        }

        [Command("heart eyes")]
        public async Task DefaultPing20()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface heart eyes");
            await ReplyAsync(Context.User.Mention + " | " + $"♥‿♥");
        }

        [Command("joyful")]
        public async Task DefaultPing23()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface joyful");
            await ReplyAsync(Context.User.Mention + " | " + $"(/◕ヮ◕)/");
        }

        [Command("kick")]
        public async Task DefaultPing24()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface kick");
            await ReplyAsync(Context.User.Mention + " | " + $"＼| ￣ヘ￣|／＿＿＿＿＿＿＿θ☆( *o*)/");
        }

        [Command("dancing")]
        public async Task DefaultPing25()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface dancing");
            await ReplyAsync(Context.User.Mention + " | " + $"♪┏(・o･)┛♪┗ ( ･o･) ┓");
        }

        [Command("cat")]
        public async Task DefaultPing26()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface cat");
            await ReplyAsync(Context.User.Mention + " | " + $"(=^·^=)");
        }

        [Command("facepalm")]
        public async Task DefaultPing27()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface facepalm");
            await ReplyAsync(Context.User.Mention + " | " + $"(－‸ლ)");
        }

        [Command("amazed")]
        public async Task DefaultPing28()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface amazed");
            await ReplyAsync(Context.User.Mention + " | " + $"＼(◎o◎)／");
        }

        [Command("happy")]
        public async Task DefaultPing29()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface happy");
            await ReplyAsync(Context.User.Mention + " | " + $"(◕‿◕✿)");
        }

        [Command("tableflip")]
        public async Task DefaultPing30()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface tableflip");
            await ReplyAsync(Context.User.Mention + " | " + $"(ノಠ益ಠ)ノ彡┻━┻");
        }

        [Command("kowtow")]
        public async Task DefaultPing31()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface kowtow");
            await ReplyAsync(Context.User.Mention + " | " + $"``m(_ _)m``");
        }

        [Command("cry")]
        public async Task DefaultPing32()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface cry");
            await ReplyAsync(Context.User.Mention + " | " + $"( ͡↑ ͜ʖ ͡↑)");
        }

        [Command("wizard")]
        public async Task DefaultPing33()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface wizard");
            await ReplyAsync(Context.User.Mention + " | " + $"╰( ͡° ͜ʖ ͡° )⊃──☆ﾟ.*");
        }

        [Command("strong")]
        public async Task DefaultPing34()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface strong");
            await ReplyAsync(Context.User.Mention + " | " + $"ᕙ( ͡° ͜ʖ ͡°)ᕗ");
        }

        [Command("dance")]
        public async Task DefaultPing35()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!txtface dance");
            await ReplyAsync(Context.User.Mention + " | " + $"ᕕ( ͡° ͜ʖ ͡°)ᕗ");
        }
    }
}
