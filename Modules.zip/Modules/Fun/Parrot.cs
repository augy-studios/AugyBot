﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules
{
    [Group("repeat")]
    [Alias("rpt", "say")]
    public class Parrot : ModuleBase<SocketCommandContext>
    {
        [Command]
        public async Task PingAsync1([Remainder] string stuffToSay = "**repeat** command syntax is ``A!repeat [text]``")
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!repeat {stuffToSay}");

            EmbedBuilder embedBuilder;
            embedBuilder = new EmbedBuilder();
            embedBuilder.WithColor(new Color(255, 0, 255));

            embedBuilder.Description = stuffToSay;

            await ReplyAsync("", false, embedBuilder);                                      
        }
    }
}
