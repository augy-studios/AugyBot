﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using SixLabors.ImageSharp;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

/*namespace AugyBot.Modules
{
    public class Cat : ModuleBase<SocketCommandContext>
    {
        private SixLabors.ImageSharp.Image image = null;
        private string randomString = "";
        private object ImageSharp;

        public async Task RandomCat()
        {
            Console.WriteLine("Making API Call...");
            using (var client = new HttpClient(new HttpClientHandler { AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate }))
            {
                string websiteurl = "http://random.cat/meow";
                client.BaseAddress = new Uri(websiteurl);
                HttpResponseMessage response = client.GetAsync("").Result;
                response.EnsureSuccessStatusCode();
                string result = await response.Content.ReadAsStringAsync();
                var json = JObject.Parse(result);
                string CatImage = json["file"].ToString();
                await ReplyAsync(CatImage);
            }
        }

        public async Task<SixLabors.ImageSharp.Image> StartStream(string url)
        {
            HttpClient httpClient = new HttpClient();
            HttpResponseMessage response = await httpClient.GetAsync(url);
            Stream inputStream = await response.Content.ReadAsStreamAsync();
            image = ImageSharp.Image.Load(inputStream);
            return image;
        }

        public async Task StopStream(IUserMessage msg)
        {
            string input = "abcdefghijklmnopqrstuvwxyz0123456789";
            char Name;
            Random rand = new Random();
            for (int i = 0; i < 8; i++)
            {
                Name = input[rand.Next(0, input.Length)];
                randomString += Name;
            }

            if (image != null)
            {
                Stream outputStream = new MemoryStream();
                image.SaveAsJpeg(outputStream); Saves the cat image as jpg (you can change this)
                outputStream.Position = 0;
                var file = File.Create($"images/{randomString}.jpg"); 
                await outputStream.CopyToAsync(file);
                file.Dispose();
                await msg.Channel.SendFileAsync($"images/{randomString}.jpg");
                File.Delete($"images/{randomString}.jpg"); 
            }
        }
    }
}
*/