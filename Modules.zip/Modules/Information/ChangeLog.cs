﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules.Information
{
    public class ChangeLog : ModuleBase<SocketCommandContext>
    {
        [Command("changelog")]
        [Alias("changes")]
        public async Task ShowChanges()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!changelog");

            EmbedBuilder embedBuilder;
            embedBuilder = new EmbedBuilder();
            embedBuilder.WithColor(new Color(255, 105, 180));

            embedBuilder.Title = $"AugyBot Change Log";
            embedBuilder.Description =
                $"__**25th December 2017**__\n" +
                $"Creation of AugyBot\n\n" +
                $"__**29th December 2017**__\n" +
                $"Launch of AugyBot and Support Server\n\n" +
                $"__**1st February 2018**__\n" +
                $"Added Python commands and features and added 4 commands\n\n" +
                $"__**24th February 2018**__\n" +
                $"Added 21 commands and made a few changes to some commands\n\n" +
                $"__**5th March 2018**__\n" +
                $"Removed 19 commands and made a few changes to some commands\n\n";
                //$"__**5th March 2018**__\n" +
                //$"Added \n\n" +

            await ReplyAsync("", false, embedBuilder);
        }
    }
}
