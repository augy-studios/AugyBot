﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules
{
    public class Server : ModuleBase<SocketCommandContext>
    {
        [Command("server")]
        [Alias("support", "botserver", "sinvite")]
        public async Task BotServer()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!server");

            await ReplyAsync("Join my support server: https://discord.gg/Fq87aGA");
        }
    }
}
