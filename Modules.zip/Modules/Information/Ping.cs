﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules
{
    [Group("ping")]
    public class Ping : ModuleBase<SocketCommandContext>
    {
        [Command]
        public async Task DefaultPing()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!ping and got {Context.Client.Latency + " ms"}");

            await ReplyAsync(Context.User.Mention + " | Pong! " + "``" + Context.Client.Latency + " ms" + "`` :ping_pong:");
        }

        [Command("user")]
        public async Task PingUser(SocketGuildUser user)
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!ping user {user} and got {Context.Client.Latency + " ms"}");

            await ReplyAsync(user.Mention + $" | Pong! " + "``" + Context.Client.Latency + " ms" + "`` :ping_pong:");
        }
    }
}
