﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules
{
    public class UserInfo : ModuleBase<SocketCommandContext>
    {
        [Command("userinfo")]
        [Alias("uinfo")]
        [Name("userinfo `<user>`")]
        public async Task PaxInfo(IGuildUser user)
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!userinfo {user}");

            var application = await Context.Client.GetApplicationInfoAsync();
            var thumbnailurl = user.GetAvatarUrl();
            var date = $"{user.CreatedAt.Month}/{user.CreatedAt.Day}/{user.CreatedAt.Year}";
            var auth = new EmbedAuthorBuilder()
            {
                Name = user.Username,
                IconUrl = thumbnailurl,
            };

            var embed = new EmbedBuilder()

            {
                Color = new Color(29, 140, 209),
                Author = auth
            };

            var us = user as SocketGuildUser;

            if (!string.IsNullOrWhiteSpace(thumbnailurl))
                embed.ThumbnailUrl = thumbnailurl;

            var D = us.Username;

            var A = us.Discriminator;
            var T = us.Id;
            var S = date;
            var C = us.Status;
            var CC = us.JoinedAt;
            var O = us.Game;
            //var R = us.Roles;

            embed.Title = $"**{us.Username}** Information";
            embed.Description = $"Username: **{D}**" +
                $"\nDiscriminator: **{A}**" +
                $"\nUser ID: **{T}**" +
                $"\nCreated at: **{S}**" +
                $"\nCurrent Status: **{C}**" +
                $"\nJoined server at: **{CC}**" +
                $"\nPlaying: **{O}**";
                //$"\nRoles: **{R}**";

            await ReplyAsync("", false, embed.Build());
        }
    }
}
