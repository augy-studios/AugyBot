﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules
{
    public class BotInfo : ModuleBase<SocketCommandContext>
    {
        [Command("botinfo")]
        [Alias("binfo")]
        [Summary("Shows All Bot Info.")]
        public async Task Info()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!botinfo");

            using (var process = Process.GetCurrentProcess())
            {
                /*this is required for up time*/
                var embed = new EmbedBuilder();
                var application = await Context.Client.GetApplicationInfoAsync(); /*for lib version*/
                embed.ImageUrl = application.IconUrl; /*pulls bot Avatar. Not needed can be removed*/
                embed.WithColor(new Color(0x030000)) /*Hexacode colours*/

                .AddField(y =>
                {
            /*new embed field*/
                    y.Name = "Creator";  /*Field name here*/
                    y.Value = application.Owner.Username; application.Owner.Id.ToString(); /*Code here. If INT convert to string*/
                    y.IsInline = false;
                })
                .AddField(y =>  /* add new field, rinse and repeat*/
                {
                    y.Name = "Uptime";
                    var time = DateTime.Now - process.StartTime; /* Subtracts current time and start time to get Uptime*/
                    var sb = new StringBuilder();
                    if (time.Days > 0)
                    {
                        sb.Append($"{time.Days}d ");
                    }
                    if (time.Hours > 0)
                    {
                        sb.Append($"{time.Hours}h ");
                    }
                    if (time.Minutes > 0)
                    {
                        sb.Append($"{time.Minutes}m ");
                    }
                    sb.Append($"{time.Seconds}s ");
                    y.Value = sb.ToString();
                    y.IsInline = true;
                })
                .AddField(y =>
                {
                    y.Name = "Discord.net version"; /*pulls discord lib version*/
                    y.Value = DiscordConfig.Version;
                    y.IsInline = true;
                }).AddField(y =>
                {
                    y.Name = "Number Of Servers";
                    y.Value = (Context.Client as DiscordSocketClient).Guilds.Count.ToString(); /*Numbers of servers the bot is in*/
                    y.IsInline = false;
                })                
                .AddField(y =>
                {
                    y.Name = "Number Of Users";
                    y.Value = (Context.Client as DiscordSocketClient).Guilds.Sum(g => g.Users.Count).ToString(); /*Counts users*/
                    y.IsInline = false;
                })
                .AddField(y =>
                {
                    y.Name = "Number Of Channels";
                    y.Value = (Context.Client as DiscordSocketClient).Guilds.Sum(g => g.Channels.Count).ToString();
                    y.IsInline = false;
                });
                await this.ReplyAsync("", embed: embed);
            }
        }        
    }
}
