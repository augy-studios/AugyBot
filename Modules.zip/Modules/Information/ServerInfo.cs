﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules
{
    public class ServerInfo : ModuleBase<SocketCommandContext>
    {
        [Command("serverinfo")]
        [Alias("sinfo", "servinfo")]
        [Remarks("Info about a server")]
        public async Task GuildInfo()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!serverinfo");

            EmbedBuilder embedBuilder;
            embedBuilder = new EmbedBuilder();
            embedBuilder.WithColor(new Color(0, 71, 171));

            var gld = Context.Guild as SocketGuild;
            var client = Context.Client as DiscordSocketClient;

            /*if (!string.IsNullOrWhiteSpace(gld.IconUrl))
                embedBuilder.ThumbnailUrl = gld.IconUrl;
            var O = gld.Owner.Username;

            var V = gld.VoiceRegionId;
            var C = gld.CreatedAt;
            var N = gld.DefaultMessageNotifications;
            var R = gld.Roles;
            var VL = gld.VerificationLevel;
            var XD = gld.Roles.Count;
            var X = gld.MemberCount;
            var Z = client.ConnectionState;*/

            if (!string.IsNullOrWhiteSpace(gld.IconUrl))
                embedBuilder.ThumbnailUrl = gld.IconUrl;

            var Name = gld.Name;
            var Owner = gld.Owner.Username + "#" + gld.Owner.Discriminator;
            var Region = gld.VoiceRegionId;
            var CreatedDate = gld.CreatedAt;
            var Notifications = gld.DefaultMessageNotifications;
            var VerificationLevel = gld.VerificationLevel;
            var RoleCount = gld.Roles.Count;
            var MemberCount = gld.MemberCount;
            var ConnectionState = client.ConnectionState;
            var ServerId = gld.Id;
            var ChannelCount = gld.Channels.Count;

            embedBuilder.Title = $"{gld.Name} Server Information";
            embedBuilder.Description = $"Server Owner: **{Owner}\n**" +
                $"Server Region: **{Region}\n**" +
                $"Created At: **{CreatedDate}\n**" +
                $"MsgNtfc: **{Notifications}\n**" +
                $"Verification: **{VerificationLevel}\n**" +
                $"Role Count: **{RoleCount}\n**" +
                $"Members: **{MemberCount}\n**" +
                $"Channels:** {ChannelCount}\n**" +
                $"Connection state:** {ConnectionState}\n**" +
                $"Server ID:** {ServerId}\n\n**";

            await ReplyAsync("", false, embedBuilder);
        }
    }
}
