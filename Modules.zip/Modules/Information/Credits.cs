﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules
{
    public class Credits : ModuleBase<SocketCommandContext>
    {
        [Command("credits")]
        public async Task ShowCredits()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!credits");

            EmbedBuilder embedBuilder;
            embedBuilder = new EmbedBuilder();
            embedBuilder.WithColor(new Color(255, 128, 0));

            embedBuilder.Title = $"AugyBot Credits";
            embedBuilder.Description = 
                $"**Coders/Developers**\n" +
                $"Augy Productions#8622\n" +
                $"**Contributors**\n" +
                $"Freeze Tiger#7763, - ̗̀ MoarChan ̖́-#9669, Diamond Koopa#7501\n" +
                $"**Support Server Staff**\n" +
                $"Matt2813";
            await ReplyAsync("", false, embedBuilder);
        }
    }
}
