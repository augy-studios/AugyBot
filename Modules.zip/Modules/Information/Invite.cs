﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules
{
    public class Invite : ModuleBase<SocketCommandContext>
    {
        [Command("invite")]
        public async Task InviteBot()
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!invite");

            var HeartFace = new Emoji("😍");

            await Context.Message.AddReactionAsync(HeartFace);
            await ReplyAsync("Add me to other servers with this link: https://discordapp.com/api/oauth2/authorize?client_id=394698118010109963&permissions=2146958583&scope=bot");
        }
    }
}
