﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AugyBot.Modules
{
    public class Kick : ModuleBase<SocketCommandContext>
    {
        [Command("Kick")]
        [RequireBotPermission(GuildPermission.KickMembers)] ///Needed BotPerms///
        [RequireUserPermission(GuildPermission.KickMembers)] ///Needed User Perms///
        public async Task KickAsync(SocketGuildUser user, [Remainder] string reason)
        {
            Console.WriteLine($"{DateTime.Now}: {Context.User.Username + "#" + Context.User.Discriminator} did a!kick {user} {reason}");

            if (user == null) throw new ArgumentException("You must mention a user");
            if (string.IsNullOrWhiteSpace(reason)) throw new ArgumentException("You must provide a reason");

            var gld = Context.Guild as SocketGuild;
            var embed = new EmbedBuilder(); ///starts embed///
            embed.WithColor(new Color(0xff0000)); ///hexacode colours ///
            embed.Title = $" {user.Username} has been kicked from {user.Guild.Name}"; ///who was kicked///
            embed.Description = $"**Username: **{user.Username}\n**Guild Name: **{user.Guild.Name}\n**Kicked by: **{Context.User.Mention}!\n**Reason: **{reason}"; ///embed values///

            await user.KickAsync(); ///kicks selected user///
            await Context.Channel.SendMessageAsync("", false, embed); ///sends embed///
        }
    }
}
